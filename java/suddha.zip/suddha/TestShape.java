package com.suddha;

public class TestShape{

    public static void main(String[] args){

        Shape myShape1 = new Shape();
        myShape1.setShape("Square");
        myShape1.printShape();
    }
}
