package com.suddha;

public class PrintSomething {

    public static void main(String[] args) {
	// write your code here

        System.out.println("Hello Java ...");
    }
}
