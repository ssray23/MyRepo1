package com.suddha;

public class HumanClass {

    private static int i = 10;

    public static void main(String args[]){
        i = i + 1;
        System.out.println("i is " + i);
    }

}
