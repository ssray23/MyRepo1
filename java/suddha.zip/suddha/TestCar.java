package com.suddha;

public class TestCar {

    public static void main(String[] args){

        Car myCar1 = new Car("Hyundai", 2019);
        myCar1.PrintCar();

        Car myCar2 = new Car("Honda", 2017);
        myCar2.PrintCar();

    }
}
